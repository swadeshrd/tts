"""
tts.

A Python package for converting the text to speech using google api.
"""

from tts.tts import TTSClass

__version__ = "0.1.0"
__author__ = 'Swadesh Ranjan Dash'
change_tts = TTSClass
