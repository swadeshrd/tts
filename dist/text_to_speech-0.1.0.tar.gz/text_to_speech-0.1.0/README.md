How to use the tts(text to speech class)
========================================
* TTSUG is used to convert the text to speech
* maximum 100 character allowed
* As per bellow example can use the package ::

    import tts

    print(tts.__version__)
    print(tts.__author__)
    tts.change_tts("Hello ! i am a bot. how may i help!")